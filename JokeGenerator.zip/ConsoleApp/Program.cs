using System;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Geotab.Test.App.Skeleton;
using Geotab.Test.App.Impl;

namespace Geotab.Test.App.MainProgram
{
    /// <summary>
    /// Main class
    /// It injects required dependencies and then calls the Application engine
    /// </summary>
    class Program
    {
        //Holds the application configuration.
        private static IConfiguration Configuration;

        //Hold name to be replaced in the joke
        public static string NAME_TO_REPLACE;

        //Holds Joke API endpoint
        private static string API_CHUCK_NORRIS;

        //Holds Name API endpoint
        private static string API_NAME_GEN;

        public static Task Main(string[] args) 
        {
            try
            {
                //Read appsettings.json file to get API configuration values
                //Configuration setup
                Configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true).Build();
                NAME_TO_REPLACE = Configuration.GetSection("NAME_TO_REPLACE").Value;
                API_CHUCK_NORRIS = Configuration.GetSection("API_CHUCK_NORRIS").Value;
                API_NAME_GEN = Configuration.GetSection("API_NAME_GEN").Value;

                //Verify if API values are available, else throw exception
                if(NAME_TO_REPLACE == null || API_CHUCK_NORRIS == null || API_NAME_GEN == null)
                {
                    throw new Exception("appsettings.json not configured properly");
                }
                return CreateHostBuilder(args).Build().RunAsync();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Error initializing the application. Please contact developer.");
            } 
            return Task.CompletedTask;
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices(services =>
                {
                    services.AddHostedService<JokeApplication>()
                            .AddScoped<IWriter, Writer>()
                            .AddScoped<IJokeFeed, JokeFeed>()
                            .AddScoped<INameFeed, NameFeed>();

                    services.AddHttpClient<IJokeFeed, JokeFeed>(client =>
                    {
                        client.BaseAddress = new Uri(Configuration["API_CHUCK_NORRIS"]);
                        client.DefaultRequestHeaders.CacheControl = new CacheControlHeaderValue
                        {
                            NoStore = true
                        };
                    });
                    services.AddHttpClient<INameFeed, NameFeed>(client =>
                    {
                        client.BaseAddress = new Uri(Configuration["API_NAME_GEN"]);
                        client.DefaultRequestHeaders.CacheControl = new CacheControlHeaderValue
                        {
                            NoStore = true
                        };
                    });
                });
    }
}