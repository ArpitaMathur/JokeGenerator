namespace Geotab.Test.App.Skeleton
{
    /// <summary>
    /// Skeleton for printing on console and logging
    /// </summary>
    public interface IWriter
    {
        void Print(string value);
        void PrintError(string value);
    }
}
