using System.Threading.Tasks;

namespace Geotab.Test.App.Skeleton
{
    /// <summary>
    /// Skeleton for calling Joke API
    /// </summary>
    public interface IJokeFeed
    {
        Task<string[]> GetRandomJokes(string category, int number);
        Task<string> GetCategories();
    }
}