using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Geotab.Test.App.Skeleton
{
    /// <summary>
    /// Skeleton for calling Joke Application
    /// </summary>
    public interface IJokeApplication
    {
        Task RunProgram();
        void PrintResults(string message);

        void VerifyResults(string result);

        char PromptUntilValidInputChar(string prompt, HashSet<char> validChars);

        int PromptUntilValidInputInt(string prompt, int lower, int upper);

        string PromptUntilValidCategory(string prompt, string allCategories);
        char GetEnteredKey(ConsoleKeyInfo consoleKeyInfo);

        Task<string[]> GetRandomJokes(string category, int number);

        Task<string> GetCategories();

        Task<string> GetNames();

        string ReplaceName(string joke, string givenName, string newName);   
    }
}