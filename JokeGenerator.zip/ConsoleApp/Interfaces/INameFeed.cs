using System.Threading.Tasks;

namespace Geotab.Test.App.Skeleton
{
    /// <summary>
    /// Skeleton for calling Name API
    /// </summary>
    public interface INameFeed
    {
        Task<string> Getnames();
    }
}