﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Geotab.Test.App.Skeleton;
using Geotab.Test.App.CustomException;
using Microsoft.Extensions.Logging; 

namespace Geotab.Test.App.Impl
{
	/// <summary>
	/// This class contains methods to call Joke API
	/// </summary>
	/// <remarks>
	/// This class can fetch joke categories and "N" number of jokes
	/// </remarks>
    public class JokeFeed : IJokeFeed
    {
		private readonly ILogger<JokeFeed> _logger;

		//HttpClient reference
		private readonly HttpClient _jokeClient;
		
		/// <summary>
		/// Dependecy Injection
		/// </summary>
		/// <param name="jokeClient">Optimized DefaultHttpClientFactory reference</param>
        public JokeFeed(HttpClient jokeClient, ILogger<JokeFeed> logger)
        {
            _jokeClient = jokeClient;
			_logger = logger;
        }
        
		/// <summary>
		/// Calls Joke API and fetches "number" of jokes
		/// </summary>
		/// <param name="category">String category of jokes to fetch</param>
		/// <param name="number">Integer number of jokes to fetch</param>
		/// <returns>An array of string tasks</returns>
		public async Task<string[]> GetRandomJokes(string category, int number)
		{
			string[] jokes = new string[number];
			//Construct URI to call
			string uri = "/jokes/random";
			if (category != null)
			{
				if (uri.Contains('?'))
					uri += "&";
				else 
					uri += "?";
				uri += "category=";
				uri += category;
			}

			for(int i=0; i<number; i++)
			{
				string joke = null;
				try
				{
					HttpResponseMessage response = await _jokeClient.GetAsync(uri);
					//Upon success, read response
					if(response.IsSuccessStatusCode)
					{
						joke = await response.Content.ReadAsStringAsync();
						//Deserialize JSON response and extract value property
						dynamic jObject = JsonConvert.DeserializeObject<dynamic>(joke);
						joke = jObject.value.ToString();
					}
					jokes[i] = joke;
				}
				catch(Exception ex)
				{
					_logger.LogError(ex.Message); 
					throw new APIErrorException("Error calling Joke API");
				}
			}
            return jokes;
        }

        

		/// <summary>
		/// Calls Joke API to fetch all the available categories
		/// </summary>
		/// <returns>A string Tasks</returns>
		public async Task<string> GetCategories()
		{
			string uri = "/jokes/categories";
			string categories = null;
			try
			{
				HttpResponseMessage response = await _jokeClient.GetAsync(uri);
				if(response.IsSuccessStatusCode)
				{
					categories = await response.Content.ReadAsStringAsync();
				}
			}
			catch(Exception ex)
			{
				_logger.LogError(ex.Message); 
				throw new APIErrorException("Error calling Joke API");
			}
			return categories;
		}
    }
}
