﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Hosting;
using Geotab.Test.App.MainProgram;
using Geotab.Test.App.Skeleton;
using Geotab.Test.App.CustomException;

namespace Geotab.Test.App.Impl
{
    /// <summary>
    /// Application engine that interacts with user and calls Joke and Name APIs
    /// It fetches joke categories, "N" number of jokes and random names according 
    /// to user provided input
    /// It can also replace the configured name in the joke with a random name
    /// </summary>
    public class JokeApplication : BackgroundService, IJokeApplication
    {   
        private IHostApplicationLifetime _hostApplicationLifetime;

        //Reference for printing messages to console and logging
        private readonly IWriter _writer;

        //Reference for calling Joke API
        private readonly IJokeFeed _jokeFeed;

        //Reference for calling Name API
        private readonly INameFeed _nameFeed;

        /// <summary>
        /// Dependency Injection
        /// </summary>
        /// <param name="consolePrinter">Writer reference</param>
        /// <param name="jokeFeed">JokeFeed reference</param>
        /// <param name="nameFeed">NameFeed reference</param>
        public JokeApplication(IWriter consolePrinter, IJokeFeed jokeFeed, 
            INameFeed nameFeed, IHostApplicationLifetime hostApplicationLifetime)
        {
            _writer = consolePrinter;
            _jokeFeed = jokeFeed;
            _nameFeed = nameFeed;
            _hostApplicationLifetime = hostApplicationLifetime;
        }

        /// <summary>
        ///  Main class that prompts user to fetch all categories of joke or a random joke
        /// For a random joke, it prompts user if they want to use a random name or not,
        /// provide a joke category or not and number of jokes to fetch
        /// If user chose a random name, it replaces the configurable NAME_TO_REPLACE in each
        /// joke with the new generated name
        /// </summary>
        public async Task RunProgram()
        {
            try
            {
                _writer.Print("Press ? to get instructions OR any other key to quit");
                char key = GetEnteredKey(Console.ReadKey());
                if (key == '?')
                {
                    while (true)
                    {
                        string allCategories = null;
                        string prompt = "Press c to get categories OR Press r to get random jokes. " +
                            "Press q to quit";
                        key = PromptUntilValidInputChar(prompt, new HashSet<char> {'c', 'r', 'q'});
                        if (key == 'c')
                        {
                            allCategories = await GetCategories();
                            VerifyResults(allCategories);
                            PrintResults(allCategories);
                        }
                        if (key == 'r')
                        {
                            string newName = null;
                            prompt = "Want to use a random name? y/n OR Press q to quit";
                            key = PromptUntilValidInputChar(prompt, new HashSet<char> {'y', 'n', 'q'});
                            if (key == 'q')
                                break;
                            if (key == 'y')
                            {
                                newName = await GetNames();
                                VerifyResults(newName);
                            }

                            string category = null;
                            prompt = "Want to specify a category? y/n OR Press q to quit";
                            key = PromptUntilValidInputChar(prompt, new HashSet<char> {'y', 'n', 'q'});
                            if (key == 'q')
                                break;
                            if (key == 'y')
                            {
                                allCategories = await GetCategories();
                                VerifyResults(allCategories);
                                PrintResults(allCategories);
                                prompt = "Enter a category from the above categories without double quotes";
                                category = PromptUntilValidCategory(prompt, allCategories);
                            }
                            
                            string[] jokes = null;
                            prompt = "How many jokes do you want? (1-9)";
                            int n = PromptUntilValidInputInt(prompt, 1, 9); 
                            jokes = await GetRandomJokes(category, n);
                            //For each joke, replace the name if needed
                            foreach(string joke in jokes)
                            { 
                                VerifyResults(joke);
                                string newJoke = joke;
                                if(newName != null)
                                    newJoke = ReplaceName(joke, Program.NAME_TO_REPLACE, newName);
                                PrintResults(newJoke);
                            }
                        }
                        //Quit if 'q' key is pressed
                        if (key == 'q') {
                            break;
                        }
                    }
                }
            }
            catch(APIErrorException ex)
            {
                _writer.PrintError(ex.Message);
            }
            catch(Exception ex)
            {
                _writer.PrintError(ex.Message);
            }
        }

        /// <summary>
        /// Method to print messages to console
        /// </summary>
        /// <param name="toPrint">String message</param>
        public void PrintResults(string message)
        {
            _writer.Print("[" + message + "]");
        }

        /// <summary>
        /// Method to check if result is null
        /// </summary>
        /// <param name="result">String result</param>
        /// <exception cref="APIErrorException">Thrown when parameter result is null</exception>
        public void VerifyResults(string result)
        {
            if(result == null)
            {
                throw new APIErrorException("Network Error. Please try again after sometime.");             
            }
        }

        /// <summary>
        /// Prompts user to enter a character until a valid character is entered
        /// </summary>
        /// <param name="prompt">String message for user</param>
        /// <param name="validChars">A collection of valid characters</param>
        /// <returns>Valid character</returns>
        public char PromptUntilValidInputChar(string prompt, HashSet<char> validChars)
        {
            _writer.Print(prompt);
            char key = GetEnteredKey(Console.ReadKey());
            //Prompt until a valid character is entered
            while(!validChars.Contains(key))
            {
                _writer.Print(prompt);
                key = GetEnteredKey(Console.ReadKey());
            }
            return key;
        }

        /// <summary>
        /// Prompts user to enter an integer until a valid integer is entered
        /// </summary>
        /// <param name="prompt">String message for user</param>
        /// <param name="lower">Integer lower bound for user input</param>
        /// <param name="upper">Integer upper bound for user input</param>
        /// <returns>Valid integer</returns>
        public int PromptUntilValidInputInt(string prompt, int lower, int upper)
        {
            char key = '\0';
            int n = Int32.MinValue;
            while(!(n >= lower && n <= upper))
            {
                _writer.Print(prompt);
                key = GetEnteredKey(Console.ReadKey());
                try 
                {
                    n = Int32.Parse(key.ToString());
                }
                catch (OverflowException) {
                    //Do nothing but prompt again
                }
                catch (FormatException) {
                    //Do nothing but prompt again
                }                
            }
            return n;
        }

        /// <summary>
        /// Prompts user to enter a category until a valid category is entered
        /// </summary>
        /// <param name="prompt">String message for user</param>
        /// <param name="allCategories">A collection of valid categories</param>
        /// <returns>A valid category</returns>
        public string PromptUntilValidCategory(string prompt, string allCategories)
        {
            _writer.Print(prompt);
            //Split string, remove double quotes and create a HashSet
            HashSet<string> categorySet = allCategories.Split(',').Select(p => p.Remove(0, 1))
                .Select(p => p.Remove(p.Length - 1, 1)).ToHashSet<string>();
            string line = Console.ReadLine();
            while(!categorySet.Contains(line))
            {
                _writer.Print(prompt);
                line = Console.ReadLine();
            }
            return line;
        }

        /// <summary>
        /// Maps the key pressed by user
        /// </summary>
        /// <param name="consoleKeyInfo">The key pressed by user</param>
        /// <returns>A valid or empty charater</returns>
        public char GetEnteredKey(ConsoleKeyInfo consoleKeyInfo)
        {
            char key = '\0';
            if (consoleKeyInfo.KeyChar == '?') 
            {
                key = '?';
            } else {
                switch (consoleKeyInfo.Key)
                {
                    case ConsoleKey.C:
                        key = 'c';
                        break;
                    case ConsoleKey.D0:
                        key = '0';
                        break;
                    case ConsoleKey.D1:
                        key = '1';
                        break;
                    case ConsoleKey.D2:
                        key = '2';
                        break;
                    case ConsoleKey.D3:
                        key = '3';
                        break;
                    case ConsoleKey.D4:
                        key = '4';
                        break;
                    case ConsoleKey.D5:
                        key = '5';
                        break;
                    case ConsoleKey.D6:
                        key = '6';
                        break;
                    case ConsoleKey.D7:
                        key = '7';
                        break;
                    case ConsoleKey.D8:
                        key = '8';
                        break;
                    case ConsoleKey.D9:
                        key = '9';
                        break;
                    case ConsoleKey.R:
                        key = 'r';
                        break;
                    case ConsoleKey.Y:
                        key = 'y';
                        break;
                    //Added for clarity
                    case ConsoleKey.N:
                        key = 'n';
                        break;
                    //Quit key
                    case ConsoleKey.Q: 
                        key = 'q';
                        break;
                }
            }
            //Pretty printing on console
            Console.WriteLine(); 
            return key;
        }

        /// <summary>
        /// Instantiates class for API calls and calls method to fetch random jokes 
        /// </summary>
        /// <param name="category">String category if provided by user or null</param>
        /// <param name="number">Integer number of jokes to fetch</param>
        /// <returns>An array of string jokes</returns>
        public async Task<string[]> GetRandomJokes(string category, int number)
        {
            //JsonFeed jsonFeed = new JsonFeed(API_CHUCK_NORRIS);
            string[] result = await _jokeFeed.GetRandomJokes(category, number);
            return result;
        }

        /// <summary>
        /// Instantiates class for API calls and calls method to fetch all joke categories 
        /// </summary>
        /// <returns>Comma-separated category of jokes</returns>
        public async Task<string> GetCategories()
        {
            //JsonFeed jsonFeed = new JsonFeed(API_CHUCK_NORRIS);
            string result = await _jokeFeed.GetCategories();
            //Remove leading and trailing [] braces
            result = result.Remove(0, 1);
            result = result.Remove(result.Length - 1, 1);
            return result;
        }

        /// <summary>
        /// Instantiates class for API calls and calls method to fetch random name
        /// </summary>
        /// <returns>String name</returns>
        public async Task<string> GetNames()
        {
            //JsonFeed jsonFeed = new JsonFeed(API_NAME_GEN);
            string name = await _nameFeed.Getnames();
            return name;
        }

       /// <summary>
       /// Replaces all instances of the given name in the joke with the new name
       /// </summary>
       /// <param name="joke">String joke</param>
       /// <param name="givenName">String name to be replaced</param>
       /// <param name="newName">String new name</param>
       /// <returns>String joke with given name replaced with new name</returns>
        public string ReplaceName(string joke, string givenName, string newName)
        {
            return joke.Replace(givenName.Trim(), newName.Trim()).Trim();
        }

        /// <summary>
        /// Asyn executor
        /// </summary>
        /// <param name="stoppingToken"></param>
        /// <returns></returns>
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await Task.Run(RunProgram);
            Console.WriteLine("GoodBye!!");
            _hostApplicationLifetime.StopApplication();
        }
    }
}
