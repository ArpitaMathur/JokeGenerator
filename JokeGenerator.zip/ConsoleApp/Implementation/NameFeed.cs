using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Geotab.Test.App.Skeleton;
using Geotab.Test.App.CustomException;

namespace Geotab.Test.App.Impl
{
	/// <summary>
	/// This class contains methods to call Joke API
	/// </summary>
	/// <remarks>
	/// This class can fetch joke categories and "N" number of jokes
	/// </remarks>
    public class NameFeed : INameFeed
	{
		//HttpClient reference
		private readonly HttpClient _nameClient;

		/// <summary>
		/// Dependecy Injection
		/// </summary>
		/// <param name="nameClient">Optimized DefaultHttpClientFactory reference</param>
        public NameFeed(HttpClient nameClient)
        {
            _nameClient = nameClient;
        }

		/// <summary>
        /// Calls Name API to fetch a random name
        /// </summary>
        /// <returns>A string task</returns>
		public async Task<string> Getnames()
		{
			string uri = "";
			string names = null;
			try
			{
				HttpResponseMessage response = await _nameClient.GetAsync(uri);
				if(response.IsSuccessStatusCode)
				{
					names = await response.Content.ReadAsStringAsync();
					//Deserialize JSON response and extract name and surname property
					dynamic jObject = JsonConvert.DeserializeObject<dynamic>(names);
					names = jObject.name.ToString().Trim() + " " + jObject.surname.ToString().Trim();
				}
			}
			catch(Exception)
			{
				throw new APIErrorException("Error calling Name API");
			}
			return names;
		}
	}
}