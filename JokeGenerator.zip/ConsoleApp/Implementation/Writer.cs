﻿using System;
using Microsoft.Extensions.Logging;
using Geotab.Test.App.Skeleton;

namespace Geotab.Test.App.Impl
{
    public class Writer : IWriter
    {
        private readonly ILogger<Writer> _logger;

        public Writer(ILogger<Writer> logger)
        {
            _logger = logger;
        }
        public void Print(string value)
        {
             Console.WriteLine(value);
             _logger.LogInformation(value);
        }

        public void PrintError(string value)
        {
             Console.WriteLine(value);
             _logger.LogError(value); 
        }
    }
}
