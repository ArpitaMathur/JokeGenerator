using System;

namespace Geotab.Test.App.CustomException
{
    /// <summary>
    /// Custom exception class that captures all the runtime exceptions
    /// </summary>
    public class APIErrorException : Exception
    {
        public APIErrorException()
        {
        }

        public APIErrorException(string message)
            : base(message)
        {
        }

        public APIErrorException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}