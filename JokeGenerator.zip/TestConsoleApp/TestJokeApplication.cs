using System;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using Xunit;
using Moq;
using Moq.Protected;
using Microsoft.Extensions.Hosting;
using System.Net;
using System.Net.Http;
using Geotab.Test.App.Skeleton;
using Geotab.Test.App.Impl;
using Microsoft.Extensions.Logging; 


namespace Geotab.Test.App.UnitTest
{
    public class TestJokeApplication
    {
        private IHostApplicationLifetime _hostApplicationLifetime;

        //Reference for printing messages to console and logging
        private readonly IWriter _writer;

        //Reference for calling Joke API
        private readonly IJokeFeed _jokeFeed;

        //Reference for calling Name API
        private readonly INameFeed _nameFeed;

        private readonly ILogger<JokeApplication> _logger;

        public TestJokeApplication()
        {
            var mockWriter = new Mock<IWriter>();
            _writer = mockWriter.Object;
            var mockJokeFeed = new Mock<IJokeFeed>();
            _jokeFeed = mockJokeFeed.Object;
            var mockNameFeed = new Mock<INameFeed>();
            _nameFeed = mockNameFeed.Object;
            var mockHostApp = new Mock<IHostApplicationLifetime>();
            _hostApplicationLifetime = mockHostApp.Object;
        }

        [Fact]
        public void PrintResults_String_ReturnsVoid()
        {
            try
            {
                //Arrange
                JokeApplication app = new JokeApplication(_writer, _jokeFeed, _nameFeed, _hostApplicationLifetime, _logger);
                //Act
                app.PrintResults("A"); 
                //Assert
                Assert.True(true); 
            }
            catch (System.Exception)
            {
                Assert.True(false);
            }
        }

        // public void VerifyResults(string result)
        // {
        // }

        // public char PromptUntilValidInputChar(string prompt, HashSet<char> validChars)
        // {
        // }

        // public int PromptUntilValidInputInt(string prompt, int lower, int upper)
        // {
        // }

        // public string PromptUntilValidCategory(string prompt, string allCategories)
        // {
        // }
        
        // public char GetEnteredKey(ConsoleKeyInfo consoleKeyInfo)
        // {
        // }

        // public Task<string[]> GetRandomJokes(string category, int number)
        // {
        // }

        // public Task<string> GetCategories()
        // {
        // }

        // public Task<string> GetNames()
        // {
        // }

        // public string ReplaceName(string joke, string givenName, string newName)
        // {
        // }
    }
}