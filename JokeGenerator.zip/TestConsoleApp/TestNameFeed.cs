using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Moq;
using Moq.Protected;
using System.Net;
using System.Net.Http;
using Geotab.Test.App.Skeleton;
using Microsoft.Extensions.Logging;
using Geotab.Test.App.Impl;


namespace Geotab.Test.App.UnitTest
{
    public class TestNameFeed
    {
        private readonly ILogger<NameFeed> _logger;

        [Fact]
        public async void Getnames_None_ReturnsString()
        {
            //Arrange
            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(@"{ ""name"": ""A"", ""surname"": ""B""}"),
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>(
                   "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);
                
            var httpClient = new HttpClient(handlerMock.Object);
            httpClient.BaseAddress = new System.Uri("https://www.names.privserv.com/api");

            INameFeed namefeed = new NameFeed(httpClient, _logger);

            //Act
            string result = await namefeed.Getnames();

            //Assert
            Assert.NotNull(result);

        }
    }
}