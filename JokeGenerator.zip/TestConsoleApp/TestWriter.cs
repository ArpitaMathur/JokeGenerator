using System;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Geotab.Test.App.Skeleton;
using Geotab.Test.App.Impl;


namespace Geotab.Test.App.UnitTest
{
    public class TestWriter
    {
        [Fact]
        public void Print_AnyString_ReturnsVoid()
        {
            try
            {
                //Arrange
                var mock = new Mock<ILogger<Writer>>();
                ILogger<Writer> logger = mock.Object;
                IWriter writer = new Writer(logger);
                //Act
                writer.Print("A");
                //Assert
                Assert.True(true);
            }
            catch(Exception)
            {
                Assert.True(false);
            }

        }

        [Fact]
        public void PrintError_AnyString_ReturnsVoid()
        {
            try
            {
                var mock = new Mock<ILogger<Writer>>();
                ILogger<Writer> logger = mock.Object;
                IWriter writer = new Writer(logger);
                writer.PrintError("B");
                Assert.True(true);
            }
            catch(Exception)
            {
                Assert.True(false);
            }

        }
    }
}