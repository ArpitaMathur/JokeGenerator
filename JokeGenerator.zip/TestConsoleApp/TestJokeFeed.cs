using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Moq;
using Moq.Protected;
using System.Net;
using System.Net.Http;
using Geotab.Test.App.Skeleton;

using Geotab.Test.App.Impl;


namespace Geotab.Test.App.UnitTest
{
    public class TestJokeFeed
    {
        [Fact]
        public async void GetCategories_None_ReturnsString()
        {
            //Arrange
            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(@"[""cat1"", ""cat2""]"),
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>(
                   "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);
                
            var httpClient = new HttpClient(handlerMock.Object);
            httpClient.BaseAddress = new System.Uri("https://api.chucknorris.io");

            IJokeFeed jokefeed = new JokeFeed(httpClient);

            //Act
            string result = await jokefeed.GetCategories();

            //Assert
            Assert.NotNull(result);

        }

        [Fact]
        public async void GetRandomJokes_NullCategory_IntNumber_ReturnsNonNullStringArray()
        {
            //Arrange
            int number = 2;
            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(@"{""value"": ""joke""}"),
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>(
                   "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);
                
            var httpClient = new HttpClient(handlerMock.Object);
            httpClient.BaseAddress = new System.Uri("https://api.chucknorris.io");

            IJokeFeed jokefeed = new JokeFeed(httpClient);

            //Act
            string[] result = await jokefeed.GetRandomJokes(null, number);

            //Assert
            Assert.Equal(result.Length, number);
            foreach(string s in result)
            {
                Assert.NotNull(s);
            }
        }

        [Fact]
        public async void GetRandomJokes_StringCategory_IntNumber_ReturnsNonNullStringArray()
        {
            //Arrange
            int number = 1;
            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(@"{""value"": ""joke""}"),
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>(
                   "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(response);
                
            var httpClient = new HttpClient(handlerMock.Object);
            httpClient.BaseAddress = new System.Uri("https://api.chucknorris.io");

            IJokeFeed jokefeed = new JokeFeed(httpClient);

            //Act
            string[] result = await jokefeed.GetRandomJokes("something", number);

            //Assert
            Assert.Equal(result.Length, number);
            foreach(string s in result)
            {
                Assert.NotNull(s);
            }
        }
    }
}