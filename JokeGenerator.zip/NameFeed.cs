using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Geotab.Test.Impl.Jokes
{
    /// <summary>
	/// This class contains methods to call Name API
	/// </summary>
	/// /// <remarks>
	/// This class can fetch a random name
	/// </remarks>
    class NameFeed
    {
        /// <summary>
        /// Calls Name API to fetch a random name
        /// </summary>
        /// <returns>A string task</returns>
		public async Task<string> Getnames()
		{
			string uri = "";
			string URL = Endpoint + uri;
			string names = null;
			try
			{
				HttpResponseMessage response = await Client.GetAsync(URL);
				if(response.IsSuccessStatusCode)
				{
					names = await response.Content.ReadAsStringAsync();
					//Deserialize JSON response and extract name and surname property
					dynamic jObject = JsonConvert.DeserializeObject<dynamic>(names);
					names = jObject.name.ToString().Trim() + " " + jObject.surname.ToString().Trim();
				}
			}
			catch(Exception)
			{
				throw new APIErrorException("Error calling Name API");
			}
			return names;
		}
    }
}